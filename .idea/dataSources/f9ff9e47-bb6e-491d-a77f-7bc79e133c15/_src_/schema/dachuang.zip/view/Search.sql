CREATE VIEW `Search` AS
  SELECT
    `dachuang`.`HeadCompany`.`HCname`       AS `HCname`,
    `dachuang`.`BranchComany`.`BCname`      AS `BCname`,
    `dachuang`.`BranchComany`.`legalperson` AS `legalperson`,
    `dachuang`.`BranchComany`.`BCid`        AS `BCid`,
    `dachuang`.`HeadCompany`.`HCid`         AS `HCid`,
    `dachuang`.`business`.`business`        AS `business`
  FROM (((`dachuang`.`HeadCompany`
    JOIN `dachuang`.`BranchComany` ON ((`dachuang`.`BranchComany`.`HCname` = `dachuang`.`HeadCompany`.`HCname`))) JOIN
    `dachuang`.`companybus` ON ((`dachuang`.`companybus`.`BCid` = `dachuang`.`BranchComany`.`BCid`))) JOIN
    `dachuang`.`business` ON (((`dachuang`.`companybus`.`tag` = `dachuang`.`business`.`tag`) AND
                               (`dachuang`.`companybus`.`tag` = `dachuang`.`business`.`tag`))))